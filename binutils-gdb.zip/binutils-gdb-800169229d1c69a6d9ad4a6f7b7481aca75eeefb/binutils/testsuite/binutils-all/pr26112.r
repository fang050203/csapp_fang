Contents of the .debug_macro section:

  Offset:                      (0x)?0
  Version:                     5
  Offset size:                 4
  Offset into .debug_line:     (0x)?0

 DW_MACRO_start_file - lineno: 0 filenum: 1
 DW_MACRO_define_strx lineno : 1 macro : -
 DW_MACRO_end_file
 DW_MACRO_define_strx lineno : 0 macro : /home/tstellar/llvm-project/clang-build
 DW_MACRO_define_strx lineno : 0 macro : FOO bar
 DW_MACRO_define_strx lineno : 0 macro : __llvm__ 1
 DW_MACRO_define_strx lineno : 0 macro : __clang__ 1
 DW_MACRO_define_strx lineno : 0 macro : __clang_major__ 11
 DW_MACRO_define_strx lineno : 0 macro : __clang_minor__ 0
 DW_MACRO_define_strx lineno : 0 macro : __clang_patchlevel__ 0
 DW_MACRO_define_strx lineno : 0 macro : __clang_version__ "11.0.0 \(https://github.com/llvm/llvm-project 10e30de8822e85839a29799b3e7b89dece3843b3\)"
 DW_MACRO_define_strx lineno : 0 macro : __GNUC__ 4
 DW_MACRO_define_strx lineno : 0 macro : __GNUC_MINOR__ 2
 DW_MACRO_define_strx lineno : 0 macro : __GNUC_PATCHLEVEL__ 1
 DW_MACRO_define_strx lineno : 0 macro : __GXX_ABI_VERSION 1002
 DW_MACRO_define_strx lineno : 0 macro : __ATOMIC_RELAXED 0
 DW_MACRO_define_strx lineno : 0 macro : __ATOMIC_CONSUME 1
 DW_MACRO_define_strx lineno : 0 macro : __ATOMIC_ACQUIRE 2
 DW_MACRO_define_strx lineno : 0 macro : __ATOMIC_RELEASE 3
 DW_MACRO_define_strx lineno : 0 macro : __ATOMIC_ACQ_REL 4
 DW_MACRO_define_strx lineno : 0 macro : __ATOMIC_SEQ_CST 5
 DW_MACRO_define_strx lineno : 0 macro : __OPENCL_MEMORY_SCOPE_WORK_ITEM 0
 DW_MACRO_define_strx lineno : 0 macro : __OPENCL_MEMORY_SCOPE_WORK_GROUP 1
 DW_MACRO_define_strx lineno : 0 macro : __OPENCL_MEMORY_SCOPE_DEVICE 2
 DW_MACRO_define_strx lineno : 0 macro : __OPENCL_MEMORY_SCOPE_ALL_SVM_DEVICES 3
 DW_MACRO_define_strx lineno : 0 macro : __OPENCL_MEMORY_SCOPE_SUB_GROUP 4
 DW_MACRO_define_strx lineno : 0 macro : __PRAGMA_REDEFINE_EXTNAME 1
 DW_MACRO_define_strx lineno : 0 macro : __VERSION__ "Clang 11.0.0 \(https://github.com/llvm/llvm-project 10e30de8822e85839a29799b3e7b89dece3843b3\)"
 DW_MACRO_define_strx lineno : 0 macro : __OBJC_BOOL_IS_BOOL 0
 DW_MACRO_define_strx lineno : 0 macro : __CONSTANT_CFSTRINGS__ 1
 DW_MACRO_define_strx lineno : 0 macro : __ORDER_LITTLE_ENDIAN__ 1234
 DW_MACRO_define_strx lineno : 0 macro : __ORDER_BIG_ENDIAN__ 4321
 DW_MACRO_define_strx lineno : 0 macro : __ORDER_PDP_ENDIAN__ 3412
 DW_MACRO_define_strx lineno : 0 macro : __BYTE_ORDER__ __ORDER_LITTLE_ENDIAN__
 DW_MACRO_define_strx lineno : 0 macro : __LITTLE_ENDIAN__ 1
 DW_MACRO_define_strx lineno : 0 macro : _LP64 1
 DW_MACRO_define_strx lineno : 0 macro : __LP64__ 1
 DW_MACRO_define_strx lineno : 0 macro : __CHAR_BIT__ 8
 DW_MACRO_define_strx lineno : 0 macro : __SCHAR_MAX__ 127
 DW_MACRO_define_strx lineno : 0 macro : __SHRT_MAX__ 32767
 DW_MACRO_define_strx lineno : 0 macro : __INT_MAX__ 2147483647
 DW_MACRO_define_strx lineno : 0 macro : __LONG_MAX__ 9223372036854775807L
 DW_MACRO_define_strx lineno : 0 macro : __LONG_LONG_MAX__ 9223372036854775807LL
 DW_MACRO_define_strx lineno : 0 macro : __WCHAR_MAX__ 2147483647
 DW_MACRO_define_strx lineno : 0 macro : __WINT_MAX__ 4294967295U
 DW_MACRO_define_strx lineno : 0 macro : __INTMAX_MAX__ 9223372036854775807L
 DW_MACRO_define_strx lineno : 0 macro : __SIZE_MAX__ 18446744073709551615UL
 DW_MACRO_define_strx lineno : 0 macro : __UINTMAX_MAX__ 18446744073709551615UL
 DW_MACRO_define_strx lineno : 0 macro : __PTRDIFF_MAX__ 9223372036854775807L
 DW_MACRO_define_strx lineno : 0 macro : __INTPTR_MAX__ 9223372036854775807L
 DW_MACRO_define_strx lineno : 0 macro : __UINTPTR_MAX__ 18446744073709551615UL
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_DOUBLE__ 8
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_FLOAT__ 4
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_INT__ 4
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_LONG__ 8
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_LONG_DOUBLE__ 16
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_LONG_LONG__ 8
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_POINTER__ 8
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_SHORT__ 2
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_PTRDIFF_T__ 8
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_SIZE_T__ 8
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_WCHAR_T__ 4
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_WINT_T__ 4
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_INT128__ 16
 DW_MACRO_define_strx lineno : 0 macro : __INTMAX_TYPE__ long int
 DW_MACRO_define_strx lineno : 0 macro : __INTMAX_FMTd__ "ld"
 DW_MACRO_define_strx lineno : 0 macro : __INTMAX_FMTi__ "li"
 DW_MACRO_define_strx lineno : 0 macro : __INTMAX_C_SUFFIX__ L
 DW_MACRO_define_strx lineno : 0 macro : __UINTMAX_TYPE__ long unsigned int
 DW_MACRO_define_strx lineno : 0 macro : __UINTMAX_FMTo__ "lo"
 DW_MACRO_define_strx lineno : 0 macro : __UINTMAX_FMTu__ "lu"
 DW_MACRO_define_strx lineno : 0 macro : __UINTMAX_FMTx__ "lx"
 DW_MACRO_define_strx lineno : 0 macro : __UINTMAX_FMTX__ "lX"
 DW_MACRO_define_strx lineno : 0 macro : __UINTMAX_C_SUFFIX__ UL
 DW_MACRO_define_strx lineno : 0 macro : __INTMAX_WIDTH__ 64
 DW_MACRO_define_strx lineno : 0 macro : __PTRDIFF_TYPE__ long int
 DW_MACRO_define_strx lineno : 0 macro : __PTRDIFF_FMTd__ "ld"
 DW_MACRO_define_strx lineno : 0 macro : __PTRDIFF_FMTi__ "li"
 DW_MACRO_define_strx lineno : 0 macro : __PTRDIFF_WIDTH__ 64
 DW_MACRO_define_strx lineno : 0 macro : __INTPTR_TYPE__ long int
 DW_MACRO_define_strx lineno : 0 macro : __INTPTR_FMTd__ "ld"
 DW_MACRO_define_strx lineno : 0 macro : __INTPTR_FMTi__ "li"
 DW_MACRO_define_strx lineno : 0 macro : __INTPTR_WIDTH__ 64
 DW_MACRO_define_strx lineno : 0 macro : __SIZE_TYPE__ long unsigned int
 DW_MACRO_define_strx lineno : 0 macro : __SIZE_FMTo__ "lo"
 DW_MACRO_define_strx lineno : 0 macro : __SIZE_FMTu__ "lu"
 DW_MACRO_define_strx lineno : 0 macro : __SIZE_FMTx__ "lx"
 DW_MACRO_define_strx lineno : 0 macro : __SIZE_FMTX__ "lX"
 DW_MACRO_define_strx lineno : 0 macro : __SIZE_WIDTH__ 64
 DW_MACRO_define_strx lineno : 0 macro : __WCHAR_TYPE__ int
 DW_MACRO_define_strx lineno : 0 macro : __WCHAR_WIDTH__ 32
 DW_MACRO_define_strx lineno : 0 macro : __WINT_TYPE__ unsigned int
 DW_MACRO_define_strx lineno : 0 macro : __WINT_WIDTH__ 32
 DW_MACRO_define_strx lineno : 0 macro : __SIG_ATOMIC_WIDTH__ 32
 DW_MACRO_define_strx lineno : 0 macro : __SIG_ATOMIC_MAX__ 2147483647
 DW_MACRO_define_strx lineno : 0 macro : __CHAR16_TYPE__ unsigned short
 DW_MACRO_define_strx lineno : 0 macro : __CHAR32_TYPE__ unsigned int
 DW_MACRO_define_strx lineno : 0 macro : __UINTMAX_WIDTH__ 64
 DW_MACRO_define_strx lineno : 0 macro : __UINTPTR_TYPE__ long unsigned int
 DW_MACRO_define_strx lineno : 0 macro : __UINTPTR_FMTo__ "lo"
 DW_MACRO_define_strx lineno : 0 macro : __UINTPTR_FMTu__ "lu"
 DW_MACRO_define_strx lineno : 0 macro : __UINTPTR_FMTx__ "lx"
 DW_MACRO_define_strx lineno : 0 macro : __UINTPTR_FMTX__ "lX"
 DW_MACRO_define_strx lineno : 0 macro : __UINTPTR_WIDTH__ 64
 DW_MACRO_define_strx lineno : 0 macro : __FLT_DENORM_MIN__ 1.40129846e-45F
 DW_MACRO_define_strx lineno : 0 macro : __FLT_HAS_DENORM__ 1
 DW_MACRO_define_strx lineno : 0 macro : __FLT_DIG__ 6
 DW_MACRO_define_strx lineno : 0 macro : __FLT_DECIMAL_DIG__ 9
 DW_MACRO_define_strx lineno : 0 macro : __FLT_EPSILON__ 1.19209290e-7F
 DW_MACRO_define_strx lineno : 0 macro : __FLT_HAS_INFINITY__ 1
 DW_MACRO_define_strx lineno : 0 macro : __FLT_HAS_QUIET_NAN__ 1
 DW_MACRO_define_strx lineno : 0 macro : __FLT_MANT_DIG__ 24
 DW_MACRO_define_strx lineno : 0 macro : __FLT_MAX_10_EXP__ 38
 DW_MACRO_define_strx lineno : 0 macro : __FLT_MAX_EXP__ 128
 DW_MACRO_define_strx lineno : 0 macro : __FLT_MAX__ 3.40282347e\+38F
 DW_MACRO_define_strx lineno : 0 macro : __FLT_MIN_10_EXP__ \(-37\)
 DW_MACRO_define_strx lineno : 0 macro : __FLT_MIN_EXP__ \(-125\)
 DW_MACRO_define_strx lineno : 0 macro : __FLT_MIN__ 1.17549435e-38F
 DW_MACRO_define_strx lineno : 0 macro : __DBL_DENORM_MIN__ 4.9406564584124654e-324
 DW_MACRO_define_strx lineno : 0 macro : __DBL_HAS_DENORM__ 1
 DW_MACRO_define_strx lineno : 0 macro : __DBL_DIG__ 15
 DW_MACRO_define_strx lineno : 0 macro : __DBL_DECIMAL_DIG__ 17
 DW_MACRO_define_strx lineno : 0 macro : __DBL_EPSILON__ 2.2204460492503131e-16
 DW_MACRO_define_strx lineno : 0 macro : __DBL_HAS_INFINITY__ 1
 DW_MACRO_define_strx lineno : 0 macro : __DBL_HAS_QUIET_NAN__ 1
 DW_MACRO_define_strx lineno : 0 macro : __DBL_MANT_DIG__ 53
 DW_MACRO_define_strx lineno : 0 macro : __DBL_MAX_10_EXP__ 308
 DW_MACRO_define_strx lineno : 0 macro : __DBL_MAX_EXP__ 1024
 DW_MACRO_define_strx lineno : 0 macro : __DBL_MAX__ 1.7976931348623157e\+308
 DW_MACRO_define_strx lineno : 0 macro : __DBL_MIN_10_EXP__ \(-307\)
 DW_MACRO_define_strx lineno : 0 macro : __DBL_MIN_EXP__ \(-1021\)
 DW_MACRO_define_strx lineno : 0 macro : __DBL_MIN__ 2.2250738585072014e-308
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_DENORM_MIN__ 3.64519953188247460253e-4951L
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_HAS_DENORM__ 1
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_DIG__ 18
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_DECIMAL_DIG__ 21
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_EPSILON__ 1.08420217248550443401e-19L
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_HAS_INFINITY__ 1
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_HAS_QUIET_NAN__ 1
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_MANT_DIG__ 64
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_MAX_10_EXP__ 4932
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_MAX_EXP__ 16384
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_MAX__ 1.18973149535723176502e\+4932L
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_MIN_10_EXP__ \(-4931\)
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_MIN_EXP__ \(-16381\)
 DW_MACRO_define_strx lineno : 0 macro : __LDBL_MIN__ 3.36210314311209350626e-4932L
 DW_MACRO_define_strx lineno : 0 macro : __POINTER_WIDTH__ 64
 DW_MACRO_define_strx lineno : 0 macro : __BIGGEST_ALIGNMENT__ 16
 DW_MACRO_define_strx lineno : 0 macro : __WINT_UNSIGNED__ 1
 DW_MACRO_define_strx lineno : 0 macro : __INT8_TYPE__ signed char
 DW_MACRO_define_strx lineno : 0 macro : __INT8_FMTd__ "hhd"
 DW_MACRO_define_strx lineno : 0 macro : __INT8_FMTi__ "hhi"
 DW_MACRO_define_strx lineno : 0 macro : __INT8_C_SUFFIX__
 DW_MACRO_define_strx lineno : 0 macro : __INT16_TYPE__ short
 DW_MACRO_define_strx lineno : 0 macro : __INT16_FMTd__ "hd"
 DW_MACRO_define_strx lineno : 0 macro : __INT16_FMTi__ "hi"
 DW_MACRO_define_strx lineno : 0 macro : __INT16_C_SUFFIX__
 DW_MACRO_define_strx lineno : 0 macro : __INT32_TYPE__ int
 DW_MACRO_define_strx lineno : 0 macro : __INT32_FMTd__ "d"
 DW_MACRO_define_strx lineno : 0 macro : __INT32_FMTi__ "i"
 DW_MACRO_define_strx lineno : 0 macro : __INT32_C_SUFFIX__
 DW_MACRO_define_strx lineno : 0 macro : __INT64_TYPE__ long int
 DW_MACRO_define_strx lineno : 0 macro : __INT64_FMTd__ "ld"
 DW_MACRO_define_strx lineno : 0 macro : __INT64_FMTi__ "li"
 DW_MACRO_define_strx lineno : 0 macro : __INT64_C_SUFFIX__ L
 DW_MACRO_define_strx lineno : 0 macro : __UINT8_TYPE__ unsigned char
 DW_MACRO_define_strx lineno : 0 macro : __UINT8_FMTo__ "hho"
 DW_MACRO_define_strx lineno : 0 macro : __UINT8_FMTu__ "hhu"
 DW_MACRO_define_strx lineno : 0 macro : __UINT8_FMTx__ "hhx"
 DW_MACRO_define_strx lineno : 0 macro : __UINT8_FMTX__ "hhX"
 DW_MACRO_define_strx lineno : 0 macro : __UINT8_C_SUFFIX__
 DW_MACRO_define_strx lineno : 0 macro : __UINT8_MAX__ 255
 DW_MACRO_define_strx lineno : 0 macro : __INT8_MAX__ 127
 DW_MACRO_define_strx lineno : 0 macro : __UINT16_TYPE__ unsigned short
 DW_MACRO_define_strx lineno : 0 macro : __UINT16_FMTo__ "ho"
 DW_MACRO_define_strx lineno : 0 macro : __UINT16_FMTu__ "hu"
 DW_MACRO_define_strx lineno : 0 macro : __UINT16_FMTx__ "hx"
 DW_MACRO_define_strx lineno : 0 macro : __UINT16_FMTX__ "hX"
 DW_MACRO_define_strx lineno : 0 macro : __UINT16_C_SUFFIX__
 DW_MACRO_define_strx lineno : 0 macro : __UINT16_MAX__ 65535
 DW_MACRO_define_strx lineno : 0 macro : __INT16_MAX__ 32767
 DW_MACRO_define_strx lineno : 0 macro : __UINT32_TYPE__ unsigned int
 DW_MACRO_define_strx lineno : 0 macro : __UINT32_FMTo__ "o"
 DW_MACRO_define_strx lineno : 0 macro : __UINT32_FMTu__ "u"
 DW_MACRO_define_strx lineno : 0 macro : __UINT32_FMTx__ "x"
 DW_MACRO_define_strx lineno : 0 macro : __UINT32_FMTX__ "X"
 DW_MACRO_define_strx lineno : 0 macro : __UINT32_C_SUFFIX__ U
 DW_MACRO_define_strx lineno : 0 macro : __UINT32_MAX__ 4294967295U
 DW_MACRO_define_strx lineno : 0 macro : __INT32_MAX__ 2147483647
 DW_MACRO_define_strx lineno : 0 macro : __UINT64_TYPE__ long unsigned int
 DW_MACRO_define_strx lineno : 0 macro : __UINT64_FMTo__ "lo"
 DW_MACRO_define_strx lineno : 0 macro : __UINT64_FMTu__ "lu"
 DW_MACRO_define_strx lineno : 0 macro : __UINT64_FMTx__ "lx"
 DW_MACRO_define_strx lineno : 0 macro : __UINT64_FMTX__ "lX"
 DW_MACRO_define_strx lineno : 0 macro : __UINT64_C_SUFFIX__ UL
 DW_MACRO_define_strx lineno : 0 macro : __UINT64_MAX__ 18446744073709551615UL
 DW_MACRO_define_strx lineno : 0 macro : __INT64_MAX__ 9223372036854775807L
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST8_TYPE__ signed char
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST8_MAX__ 127
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST8_FMTd__ "hhd"
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST8_FMTi__ "hhi"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST8_TYPE__ unsigned char
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST8_MAX__ 255
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST8_FMTo__ "hho"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST8_FMTu__ "hhu"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST8_FMTx__ "hhx"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST8_FMTX__ "hhX"
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST16_TYPE__ short
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST16_MAX__ 32767
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST16_FMTd__ "hd"
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST16_FMTi__ "hi"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST16_TYPE__ unsigned short
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST16_MAX__ 65535
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST16_FMTo__ "ho"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST16_FMTu__ "hu"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST16_FMTx__ "hx"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST16_FMTX__ "hX"
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST32_TYPE__ int
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST32_MAX__ 2147483647
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST32_FMTd__ "d"
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST32_FMTi__ "i"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST32_TYPE__ unsigned int
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST32_MAX__ 4294967295U
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST32_FMTo__ "o"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST32_FMTu__ "u"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST32_FMTx__ "x"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST32_FMTX__ "X"
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST64_TYPE__ long int
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST64_MAX__ 9223372036854775807L
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST64_FMTd__ "ld"
 DW_MACRO_define_strx lineno : 0 macro : __INT_LEAST64_FMTi__ "li"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST64_TYPE__ long unsigned int
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST64_MAX__ 18446744073709551615UL
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST64_FMTo__ "lo"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST64_FMTu__ "lu"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST64_FMTx__ "lx"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_LEAST64_FMTX__ "lX"
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST8_TYPE__ signed char
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST8_MAX__ 127
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST8_FMTd__ "hhd"
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST8_FMTi__ "hhi"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST8_TYPE__ unsigned char
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST8_MAX__ 255
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST8_FMTo__ "hho"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST8_FMTu__ "hhu"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST8_FMTx__ "hhx"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST8_FMTX__ "hhX"
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST16_TYPE__ short
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST16_MAX__ 32767
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST16_FMTd__ "hd"
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST16_FMTi__ "hi"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST16_TYPE__ unsigned short
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST16_MAX__ 65535
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST16_FMTo__ "ho"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST16_FMTu__ "hu"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST16_FMTx__ "hx"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST16_FMTX__ "hX"
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST32_TYPE__ int
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST32_MAX__ 2147483647
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST32_FMTd__ "d"
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST32_FMTi__ "i"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST32_TYPE__ unsigned int
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST32_MAX__ 4294967295U
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST32_FMTo__ "o"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST32_FMTu__ "u"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST32_FMTx__ "x"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST32_FMTX__ "X"
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST64_TYPE__ long int
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST64_MAX__ 9223372036854775807L
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST64_FMTd__ "ld"
 DW_MACRO_define_strx lineno : 0 macro : __INT_FAST64_FMTi__ "li"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST64_TYPE__ long unsigned int
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST64_MAX__ 18446744073709551615UL
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST64_FMTo__ "lo"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST64_FMTu__ "lu"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST64_FMTx__ "lx"
 DW_MACRO_define_strx lineno : 0 macro : __UINT_FAST64_FMTX__ "lX"
 DW_MACRO_define_strx lineno : 0 macro : __USER_LABEL_PREFIX__
 DW_MACRO_define_strx lineno : 0 macro : __FINITE_MATH_ONLY__ 0
 DW_MACRO_define_strx lineno : 0 macro : __GNUC_STDC_INLINE__ 1
 DW_MACRO_define_strx lineno : 0 macro : __GCC_ATOMIC_TEST_AND_SET_TRUEVAL 1
 DW_MACRO_define_strx lineno : 0 macro : __CLANG_ATOMIC_BOOL_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __CLANG_ATOMIC_CHAR_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __CLANG_ATOMIC_CHAR16_T_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __CLANG_ATOMIC_CHAR32_T_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __CLANG_ATOMIC_WCHAR_T_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __CLANG_ATOMIC_SHORT_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __CLANG_ATOMIC_INT_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __CLANG_ATOMIC_LONG_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __CLANG_ATOMIC_LLONG_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __CLANG_ATOMIC_POINTER_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __GCC_ATOMIC_BOOL_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __GCC_ATOMIC_CHAR_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __GCC_ATOMIC_CHAR16_T_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __GCC_ATOMIC_CHAR32_T_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __GCC_ATOMIC_WCHAR_T_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __GCC_ATOMIC_SHORT_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __GCC_ATOMIC_INT_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __GCC_ATOMIC_LONG_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __GCC_ATOMIC_LLONG_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __GCC_ATOMIC_POINTER_LOCK_FREE 2
 DW_MACRO_define_strx lineno : 0 macro : __NO_INLINE__ 1
 DW_MACRO_define_strx lineno : 0 macro : __FLT_EVAL_METHOD__ 0
 DW_MACRO_define_strx lineno : 0 macro : __FLT_RADIX__ 2
 DW_MACRO_define_strx lineno : 0 macro : __DECIMAL_DIG__ __LDBL_DECIMAL_DIG__
 DW_MACRO_define_strx lineno : 0 macro : __GCC_ASM_FLAG_OUTPUTS__ 1
 DW_MACRO_define_strx lineno : 0 macro : __code_model_small__ 1
 DW_MACRO_define_strx lineno : 0 macro : __amd64__ 1
 DW_MACRO_define_strx lineno : 0 macro : __amd64 1
 DW_MACRO_define_strx lineno : 0 macro : __x86_64 1
 DW_MACRO_define_strx lineno : 0 macro : __x86_64__ 1
 DW_MACRO_define_strx lineno : 0 macro : __SEG_GS 1
 DW_MACRO_define_strx lineno : 0 macro : __SEG_FS 1
 DW_MACRO_define_strx lineno : 0 macro : __seg_gs __attribute__\(\(address_space\(256\)\)\)
 DW_MACRO_define_strx lineno : 0 macro : __seg_fs __attribute__\(\(address_space\(257\)\)\)
 DW_MACRO_define_strx lineno : 0 macro : __k8 1
 DW_MACRO_define_strx lineno : 0 macro : __k8__ 1
 DW_MACRO_define_strx lineno : 0 macro : __tune_k8__ 1
 DW_MACRO_define_strx lineno : 0 macro : __REGISTER_PREFIX__
 DW_MACRO_define_strx lineno : 0 macro : __NO_MATH_INLINES 1
 DW_MACRO_define_strx lineno : 0 macro : __FXSR__ 1
 DW_MACRO_define_strx lineno : 0 macro : __SSE2__ 1
 DW_MACRO_define_strx lineno : 0 macro : __SSE2_MATH__ 1
 DW_MACRO_define_strx lineno : 0 macro : __SSE__ 1
 DW_MACRO_define_strx lineno : 0 macro : __SSE_MATH__ 1
 DW_MACRO_define_strx lineno : 0 macro : __MMX__ 1
 DW_MACRO_define_strx lineno : 0 macro : __GCC_HAVE_SYNC_COMPARE_AND_SWAP_1 1
 DW_MACRO_define_strx lineno : 0 macro : __GCC_HAVE_SYNC_COMPARE_AND_SWAP_2 1
 DW_MACRO_define_strx lineno : 0 macro : __GCC_HAVE_SYNC_COMPARE_AND_SWAP_4 1
 DW_MACRO_define_strx lineno : 0 macro : __GCC_HAVE_SYNC_COMPARE_AND_SWAP_8 1
 DW_MACRO_define_strx lineno : 0 macro : __SIZEOF_FLOAT128__ 16
 DW_MACRO_define_strx lineno : 0 macro : unix 1
 DW_MACRO_define_strx lineno : 0 macro : __unix 1
 DW_MACRO_define_strx lineno : 0 macro : __unix__ 1
 DW_MACRO_define_strx lineno : 0 macro : linux 1
 DW_MACRO_define_strx lineno : 0 macro : __linux 1
 DW_MACRO_define_strx lineno : 0 macro : __linux__ 1
 DW_MACRO_define_strx lineno : 0 macro : __ELF__ 1
 DW_MACRO_define_strx lineno : 0 macro : __gnu_linux__ 1
 DW_MACRO_define_strx lineno : 0 macro : __FLOAT128__ 1
 DW_MACRO_define_strx lineno : 0 macro : __STDC__ 1
 DW_MACRO_define_strx lineno : 0 macro : __STDC_HOSTED__ 1
 DW_MACRO_define_strx lineno : 0 macro : __STDC_VERSION__ 201710L
