.*: Info: Unable to display section 0 - it has a NULL type
